var files_dup =
[
    [ "doc_pages", "dir_69c0ad47d15d71cfac8e0d206e4e350d.html", null ],
    [ "Header.h", "_header_8h.html", "_header_8h" ],
    [ "Source.cpp", "_source_8cpp.html", "_source_8cpp" ],
    [ "Source.h", "_source_8h.html", "_source_8h" ],
    [ "V2.0.cpp", "_v2_80_8cpp.html", "_v2_80_8cpp" ]
];