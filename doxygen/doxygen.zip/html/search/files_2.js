var searchData=
[
  ['v2_2e0_2ecpp_0',['V2.0.cpp',['../_v2_80_8cpp.html',1,'']]],
  ['versiju_5fhistory_2emd_1',['Versiju_history.md',['../_versiju__history_8md.html',1,'']]]
];
