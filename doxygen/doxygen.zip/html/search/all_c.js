var searchData=
[
  ['trumpaiapiestudenta_0',['trumpaiApieStudenta',['../class_zmogus.html#a55db96b839195c335d3a2e3e9afc1567',1,'Zmogus::trumpaiApieStudenta()'],['../class_studentas.html#ab43c0e24509465e553350972d1c6d15d',1,'Studentas::trumpaiApieStudenta()']]]
];
