var searchData=
[
  ['main_0',['main',['../_v2_80_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'V2.0.cpp']]],
  ['moteriskos_5fpavardes_1',['Moteriskos_pavardes',['../_source_8h.html#afec017d542ca3c713cc517c99c923143',1,'Source.h']]]
];
