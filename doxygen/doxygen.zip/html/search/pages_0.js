var searchData=
[
  ['versijų_20istorija_0',['Versijų istorija',['../md_doc_pages__versiju_history.html',1,'']]]
];
