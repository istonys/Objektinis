var searchData=
[
  ['pavarde_0',['pavarde',['../class_zmogus.html#a0ccc9864e6fb821e519fc50afd96dfe1',1,'Zmogus::pavarde() const'],['../class_zmogus.html#a07f3b742e4b23dcba7506025b50ad32e',1,'Zmogus::pavarde(const string &amp;pavarde)'],['../class_studentas.html#ad99149fe51ed49980055bdf83615e0f0',1,'Studentas::pavarde()'],['../class_studentas.html#abfc7c1fd23b0feec8832c691af2ca016',1,'Studentas::pavarde(string pavarde)']]],
  ['prideti_5fpazymi_1',['prideti_pazymi',['../class_studentas.html#adaf71cf17c3a1c2185373430775cb9fb',1,'Studentas']]]
];
