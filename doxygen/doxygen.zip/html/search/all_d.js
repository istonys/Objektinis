var searchData=
[
  ['v2_2e0_2ecpp_0',['V2.0.cpp',['../_v2_80_8cpp.html',1,'']]],
  ['vardai_1',['Vardai',['../_source_8h.html#a92e9c9e4949ce27fb67c16cb3698bbb6',1,'Source.h']]],
  ['vardas_2',['Vardas',['../class_zmogus.html#ad752feab373733e70e2101724e8d1d9d',1,'Zmogus']]],
  ['vardas_3',['vardas',['../class_zmogus.html#a9ba88c78eedc8094a3b38cdf55228bae',1,'Zmogus::vardas() const'],['../class_zmogus.html#ac6047cdb4318590f1967473e231b86cf',1,'Zmogus::vardas(const string &amp;vardas)'],['../class_studentas.html#a312e7a75f38153fe8358751b07e8c787',1,'Studentas::vardas()'],['../class_studentas.html#af37202dd2834c12d5a617b30d45da2c3',1,'Studentas::vardas(string vardas)']]],
  ['versijų_20istorija_4',['Versijų istorija',['../md_doc_pages__versiju_history.html',1,'']]],
  ['versiju_5fhistory_2emd_5',['Versiju_history.md',['../_versiju__history_8md.html',1,'']]],
  ['vidurkis_6',['Vidurkis',['../class_zmogus.html#a48bcfa71b558718581842931bb0a0412',1,'Zmogus']]],
  ['vidurkis_7',['vidurkis',['../class_zmogus.html#a367870f22a6402c977ccb14c52ad457c',1,'Zmogus::vidurkis() const'],['../class_zmogus.html#a13b98912439348a1027f962b71ce224f',1,'Zmogus::vidurkis(int vidurkis)']]],
  ['vyriskos_5fpavardes_8',['Vyriskos_pavardes',['../_source_8h.html#a7145195d1609cad9fb94aea89ec0d1d3',1,'Source.h']]]
];
