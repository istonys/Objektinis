var searchData=
[
  ['nustatyti_5fegzamino_5fbala_0',['nustatyti_egzamino_bala',['../class_studentas.html#a2c7c368ad84494bb9572c0a95e61ae70',1,'Studentas']]]
];
