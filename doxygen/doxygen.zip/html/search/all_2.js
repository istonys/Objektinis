var searchData=
[
  ['gauti_5fegzamino_5fbala_0',['gauti_egzamino_bala',['../class_studentas.html#a390a8eb952bcdad4a0d3a2f31e30d33c',1,'Studentas']]],
  ['gauti_5fmediana_1',['gauti_mediana',['../class_studentas.html#a58857d43601ded20f2dcb1377bc0f602',1,'Studentas']]],
  ['gauti_5fpazymius_2',['gauti_pazymius',['../class_studentas.html#a4002ed99f45d44366a597471bee4615c',1,'Studentas']]],
  ['gauti_5fvidurki_3',['gauti_vidurki',['../class_studentas.html#a1900c91256d15903809b416e2943a1eb',1,'Studentas']]],
  ['generuoti_4',['Generuoti',['../_source_8cpp.html#aa67ea6eec06d56ee971c82fe63751d7b',1,'Generuoti():&#160;Source.cpp'],['../_source_8h.html#aa67ea6eec06d56ee971c82fe63751d7b',1,'Generuoti():&#160;Source.cpp']]]
];
