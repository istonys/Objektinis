var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#a9ba88c78eedc8094a3b38cdf55228bae',1,'Zmogus::vardas() const'],['../class_zmogus.html#ac6047cdb4318590f1967473e231b86cf',1,'Zmogus::vardas(const string &amp;vardas)'],['../class_studentas.html#a312e7a75f38153fe8358751b07e8c787',1,'Studentas::vardas()'],['../class_studentas.html#af37202dd2834c12d5a617b30d45da2c3',1,'Studentas::vardas(string vardas)']]],
  ['vidurkis_1',['vidurkis',['../class_zmogus.html#a367870f22a6402c977ccb14c52ad457c',1,'Zmogus::vidurkis() const'],['../class_zmogus.html#a13b98912439348a1027f962b71ce224f',1,'Zmogus::vidurkis(int vidurkis)']]]
];
