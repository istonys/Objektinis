var class_zmogus =
[
    [ "Zmogus", "class_zmogus.html#aa7a8ba4d3c4778f9b35d59eef3e72574", null ],
    [ "~Zmogus", "class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d", null ],
    [ "pavarde", "class_zmogus.html#a0ccc9864e6fb821e519fc50afd96dfe1", null ],
    [ "pavarde", "class_zmogus.html#a07f3b742e4b23dcba7506025b50ad32e", null ],
    [ "trumpaiApieStudenta", "class_zmogus.html#a55db96b839195c335d3a2e3e9afc1567", null ],
    [ "vardas", "class_zmogus.html#a9ba88c78eedc8094a3b38cdf55228bae", null ],
    [ "vardas", "class_zmogus.html#ac6047cdb4318590f1967473e231b86cf", null ],
    [ "vidurkis", "class_zmogus.html#a367870f22a6402c977ccb14c52ad457c", null ],
    [ "vidurkis", "class_zmogus.html#a13b98912439348a1027f962b71ce224f", null ],
    [ "Pavarde", "class_zmogus.html#a2300d6db4227967c96dd83a555fa7b86", null ],
    [ "Vardas", "class_zmogus.html#ad752feab373733e70e2101724e8d1d9d", null ],
    [ "Vidurkis", "class_zmogus.html#a48bcfa71b558718581842931bb0a0412", null ]
];